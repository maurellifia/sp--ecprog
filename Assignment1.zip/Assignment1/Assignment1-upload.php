<?php
session_start();


if(isset($_POST['getUrl']))
{
 $url=$_POST['url'];
 $data = file_get_contents($url);
 $new = 'http://Domain/image';
 file_put_contents($new, $data);
 echo "http://Domain/link-info-karet2023";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action ="" method="POST">
        <h1> Upload url here</h1>
        <input type="text" name="url"/>
        <input type="submit" value="Send Url">
    </form>
</body>
</html>
