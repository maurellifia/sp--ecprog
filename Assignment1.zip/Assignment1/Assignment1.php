<?php
    session_start();

    Function Cookies(){
        $CookieName = 'weblogin';
        $value = 'true';
        $expires= time()+86400*30;
        $path = "";
        $domain = "";
        $secure = true;
        $httponly = true;
        setcookie($CookieName,$value,$expires,$path,$domain, $secure,$httponly);
    }
    

    if (isset($_POST['username']) && isset($_POST['password'])) {

        $username = $_POST['username'];
        $password = $_POST['password'];

        $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password';";

        $result = $connection->query($query);

        if ($result->num_rows > 0) {

            $row = $result->fetch_assoc();
            cookies();
            $_SESSION['is_login'] = true;
            $_SESSION['full_name'] = $row['fullname'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['user_id'] = $row['id'];

            echo "Login Success!";

            header('Location: ../messages.php');
        }
        else {
            echo "Username or Password are inccorect!";
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST">
        <h1> Login </h1>
        <input type="text" name="Username"/>
        <input type="password" name="Password"/>
        <input type="submit">
    </form>
</body>
</html>